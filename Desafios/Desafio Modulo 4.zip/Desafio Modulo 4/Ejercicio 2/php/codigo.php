<?php

$nombre = $_POST['nombre'];
$pass = $_POST['pass'];
echo 'Hola tu nombre es'.$nombre;
echo 'Hola tu contraseña es'.$pass;



?>